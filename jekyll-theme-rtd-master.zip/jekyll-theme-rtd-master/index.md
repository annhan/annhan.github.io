---
layout: default
title: Local Development Index Page
nav_order: 1
---

# Local Development Index Page

This index page is only visible if developing the theme as Jekyll is served
from the repository top directory.

The Docs folder index page can be reached following
[this link](docs/index.html).

In the normal GitHub Pages deployment the Docs index can be reached clicking
on the home link at the top of the left navigation bar.
