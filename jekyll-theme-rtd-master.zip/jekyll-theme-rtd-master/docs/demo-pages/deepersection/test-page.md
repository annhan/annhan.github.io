---
layout: default
title: A Page In A Deeper Section
excerpt: A sample description for SEO.
nav_order: 3
---

# A Page In A Deeper Section

This is an page has two interesting things about it:

- It has the same filename as another page, but inside a subfolder
- It is two levels down, so while the second level shouldn't appear up in the
  navigation menu on the left, you can still see it in the breadcrumbs at the
  top
